package icia.spring.help.services.auth;

public interface Auth {

		public void backController();
		
		public void initCtl();
		
		public void accessCtl();
		
		public void access();
			
		public void storeList();
		
		public void accessOutCtl();

		public void isAccess();
			
		public void convertToBoolean();
			
}
