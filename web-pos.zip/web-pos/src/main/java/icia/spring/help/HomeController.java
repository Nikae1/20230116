package icia.spring.help;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import icia.spring.help.bean.GroupBean;
import icia.spring.help.services.auth.Authentication;
import icia.spring.help.services.utils.ClientInfo;
import lombok.extern.slf4j.Slf4j;

/**
 * Handles requests for the application home page.
 */
@Controller
@Slf4j
public class HomeController {
	
	@Autowired
	private Authentication auth;
	
	
	
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
//	@RequestMapping(value = "/", method = RequestMethod.GET)
//	public String home(Locale locale, Model model) {
//		logger.info("Welcome home! The client locale is {}.", locale);
//		
//		Date date = new Date();
//		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
//		
//		String formattedDate = dateFormat.format(date);
//		
//		model.addAttribute("serverTime", formattedDate );
//		
//		return "home";
//	}
//	

	@RequestMapping(value = {"/", "/Index"}, method = RequestMethod.GET)
	public String index() {
		System.out.println("*******진입*******");
		
		return "index";
	}
	
	@RequestMapping(value = {"/Joinform"}, method = RequestMethod.GET)
	public String joinstep() {
		System.out.println("*******joinform*******");
		
		return "joinform";
	}
	
	//, @RequestHeader Map(String, String) headerInfo request의 header에서 모든 정보를
	//가지고 오는 구문
	@RequestMapping(value = {"/Access"}, method = RequestMethod.POST)
	public ModelAndView Access(ModelAndView mav, @ModelAttribute GroupBean group) {
		
		
		
		//key값을 주지않으면 server에서 추출할 때 class이름으로 접근해야 한다.
		mav.addObject("Group", group);
		mav.setViewName("main");
		
		log.info("{}", group);
		
		
		auth.backController(1, mav);
		
		System.out.println("*******로그인 처리*******");
		
		return mav;
	}

	@RequestMapping(value = {"/Access"}, method = RequestMethod.GET)
	public String Access() {
		
		
		System.out.println("*******잘못된 접근*******");
		
		return "index";
	}
	
	

	
}
