package icia.spring.help.bean;

import lombok.Data;

@Data
public class ImagesBean {
	private String imageCode;
	private String imageDisplayName;
	private String imageLocation;
	
	
	
}
