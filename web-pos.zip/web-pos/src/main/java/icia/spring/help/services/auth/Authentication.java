package icia.spring.help.services.auth;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import icia.spring.help.bean.CategoriesBean;
import icia.spring.help.bean.GroupBean;
import icia.spring.help.services.utils.ClientInfo;
import icia.spring.help.services.utils.Encryption;
import icia.spring.help.services.utils.ProjectUtils;
import icia.spring.help.services.utils.SimpleTransactionManager;
import icia.spring.help.services.utils.TransactionAssistant;
import lombok.extern.slf4j.Slf4j;

/**/
@Service
@Slf4j
public class Authentication extends TransactionAssistant {

	@Autowired
	private Encryption enc;
	@Autowired
	private ClientInfo clientInfo;
	@Autowired
	private ProjectUtils utils;
	
	private SimpleTransactionManager tranManager;
	
	public Authentication() {}
	
	public void backController(int serviceCode, Model model) {
		switch(serviceCode) {
		case 11:
			this.groupNameDuplicateCheckCtl(model);
			break;
			
		case 10:	
			this.isStoreCodeCtl(model);
			break;
			
		case 12:
			this.memberJoinCtl(model);
			break;
			
		case 22:
			this.deleteTempGroupName(model);
			break;
			
		}
	}

	public void backController(int serviceCode, ModelAndView mav) {
		switch(serviceCode) {
		case 1:
			this.loginCtl(mav);
			break;
		}
	}
	
	
	
	/* 로그인을 하기위한 메소드 */
	private void loginCtl(ModelAndView mav) {
		GroupBean group = ((GroupBean)mav.getModel().get("Group"));
		String page = "index";
		System.out.println("loginCtl");
		
		log.info("{}", group);
		
		this.tranManager = this.getTransaction(false);
		try {
			this.tranManager.tranStart();
			
			
			//암호화된 비밀번호와 복호화된 비밀번호를 매치
			if(enc.matches(group.getStoreInfoList().get(0).getEmpList().get(0).getEmpPin(), this.sqlSession.selectOne("matchPin", group))) {
				System.out.println(11111111);
				if(this.convertToBoolean(this.sqlSession.selectOne("isloginInfo", group))){
					System.out.println(22222222);
					
					group.getStoreInfoList().get(0).getEmpList().get(0).
					getAccessList().get(0).setAccessBrowser(this.clientInfo.getBrowserInfo(utils.getHeaderInfo(false)));
					group.getStoreInfoList().get(0).getEmpList().get(0).
					getAccessList().get(0).setAccessLocation(utils.getHeaderInfo(true));
					
					mav.addObject(group);
					
					group.getStoreInfoList().get(0).getEmpList().get(0).getAccessList().get(0).setAccessPublicIp(group.getStoreInfoList().get(0).getEmpList().get(0).
							getAccessList().get(0).getAccessPublicIp());
				//	group.getStoreInfoList().get(0).getEmpList().get(0).getAccessList().get(0).setAccessBrowser("null");
				//	group.getStoreInfoList().get(0).getEmpList().get(0).getAccessList().get(0).setAccessLocation("null");
					group.getStoreInfoList().get(0).getEmpList().get(0).getAccessList().get(0).setAccessState("R");
					group.getStoreInfoList().get(0).getEmpList().get(0).getAccessList().get(0).setAccessType(1);
					
					
					
					if(this.convertToBoolean(this.sqlSession.insert("insAccessLog", group))){
						System.out.println(3333333);
						this.tranManager.commit();
						log.info("{}", group);
					}
				}else group.setMessage("로그인 오류: 사용자의 정보가 일치하지 않습니다.");
			}else group.setMessage("비밀번호 오류: 비밀번호가 일치하지 않습니다.");
					
	}catch(Exception e){ e.printStackTrace();
		this.tranManager.rollback();
	}finally{this.tranManager.tranEnd();
	mav.setViewName(page);}
}
	
	
	/* 중복체크 검사 */
	private void groupNameDuplicateCheckCtl(Model model) {
		GroupBean group = ((GroupBean)model.getAttribute("group"));
	//	log.info("{}", ((GroupBean)model.getAttribute("group")).getGroupName());
	
		this.tranManager = this.getTransaction(false);
		
		try {
			this.tranManager.tranStart();
		/* Temp에 중복검사 // 동시에 같은 groupName을 사용하는 경우를 대비 */
	if(!this.convertToBoolean(this.sqlSession.selectOne("isGroupName", group))) {
		
		if(this.convertToBoolean(this.sqlSession.insert("insTemp", group))) {
			this.tranManager.commit();
		}else {group.setMessage("NetWork Error: 네트워크가 불안정합니다. 잠시 후 다시 이용해주세요.");}
	
	}
	else {group.setMessage("GroupName Error: 이미 사용중인 그룹명입니다. 다른 이름을 사용해주세요.");
		  group.setGroupName(null);}
	}
	catch(Exception e){ e.printStackTrace();
		this.tranManager.rollback();
	}
		finally{this.tranManager.tranEnd();}
	}

	
	private void memberJoinCtl(Model model) {
		String[][] levInfo = {{"L1", "그룹대표"},{"L2", "매니저"},{"L3", "직원"}};
		String message = null;
		boolean delResult = false;
		CategoriesBean category = null;
		ArrayList<CategoriesBean> categoryList = null;
		
		GroupBean group = ((GroupBean)model.getAttribute("group"));
		
		/* SHA 암호화 처리 */
		String encPassword = enc.encode(group.getGroupPin());
		group.setGroupPin(encPassword);
		group.getStoreInfoList().get(0).getEmpList().get(0).setEmpPin(encPassword);
		
		/* AES 암호화 처리 */
		try {
			String aesEncode = enc.aesEncode(group.getGroupCeo(), group.getGroupName()+group.getStoreInfoList().get(0).getStoreCode());
			
			group.setGroupCeo(aesEncode);
			group.getStoreInfoList().get(0).getEmpList().get(0).setEmpName(aesEncode);
		} catch (Exception e) {e.printStackTrace();} 
		
		/* Transaction Start */
		try {
			this.tranManager = getTransaction(false);
			this.tranManager.tranStart();

			log.info("{}", group);
			if(this.convertToBoolean(this.sqlSession.insert("insGroup", group))) {
				if(this.convertToBoolean(this.sqlSession.insert("insStore", group))) {
					
					/* Default CategoriesInfo */
					for (String[] lev : levInfo) {
						categoryList = new ArrayList<CategoriesBean>();
						/*
						 * 카테고리에 들어갈 직원등급과 명칭을 미리 [INS]시켜주기위한 add를 사용할 경우 덮어씌기가 안되므로, 들어있는 값을 반드시 clear를
						 * 해줘야 한다
						 */
						if (categoryList.size() != 0)
							categoryList.clear();
						
						category = new CategoriesBean();
						category.setLevCode(lev[0]);
						category.setLevName(lev[1]);
						categoryList.add(category);
						
						group.getStoreInfoList().get(0).setCateList(categoryList);
						this.sqlSession.insert("insCategory", group);
						
					}
					if(this.convertToBoolean(this.sqlSession.insert("insEmp", group))) {
						this.tranManager.commit();
					}
				}
			}
		} catch (Exception e) {
			this.tranManager.rollback();
		} finally {
			this.tranManager.tranEnd();
			
				delResult = this.convertToBoolean(this.sqlSession.insert("delTemp", group));
				if (delResult) {
					/* AES 암호 복호화 */
					try {
						String aesDecode = enc.aesDecode(group.getGroupCeo(),
								group.getGroupName() + group.getStoreInfoList().get(0).getStoreCode());

						group.setGroupCeo(aesDecode);
					} catch (Exception e) {
						e.printStackTrace();
					}

					message = (delResult)
							? "회원가입성공:" + group.getGroupCeo() + "님 회원가입을 감사드립니다.\n아래의 정보로 로그인 해주세요.\n" + "[GroupCode >>>"
									+ group.getGroupCode() + "]\n" + "[StoreCode >>>"
									+ group.getStoreInfoList().get(0).getStoreCode() + "]\n" + "[EmployeeCode >>> "
									+ group.getStoreInfoList().get(0).getEmpList().get(0).getEmpCode() + "]"
							: "회원가입 오류:일시적인 장애로 회원가입이 되지 않았습니다. 잠시후 다시 시도해 주세요.";
				} else
					message = (delResult) ? "정상처리:이전에 입력된 그룹네임이 삭제되었습니다."
							: "그룹네임 삭제 오류:이전에 입력된 그룹네임이 삭제되지 않아 이전 그룹네임을 사용할 수 없습니다.";

				/* 그룹네임 삭제 후 기존 입력 정보 지우기 */
				group.setMessage(message);
				group.setGroupName(null);
				group.setGroupPin(null);
				group.setGroupCeo(null);
				group.setStoreInfoList(null);					
	}
	}
	
	/* 임시 저장된 GroupName 삭제 */
	private void deleteTempGroupName(Model model) {
		GroupBean group = (GroupBean)model.getAttribute("group");
		
		/* Transaction Start */
		this.tranManager = getTransaction(true);
		try {
			this.tranManager.tranStart();
		
		if(group.getGroupName() != "") {
			
			String message = (this.convertToBoolean(this.sqlSession.delete("delTemp", group)))? 
					"정상처리:이전에 입력된 그룹네임이 삭제되었습니다.": "그룹네임 삭제 오류:이전에 입력된 그룹네임이 삭제되지 않아 이전 그룹네임을 사용할 수 없습니다.";
			/* 그룹네임 삭제 후 기존 입력 정보 지우기 */
			group.setMessage(message);
//			group.setGroupName(null);
//			group.setGroupPin(null);
//			group.setGroupCeo(null);
//			group.setStoreInfoList(null);
//			
		}
		} catch (Exception e) {e.printStackTrace();} 
		finally {this.tranManager.tranEnd();}
	}
	
	/* PK인 storeCode의 중복검사 */
	private void isStoreCodeCtl(Model model) {
		GroupBean group = (GroupBean)model.getAttribute("group");
		
		log.info("{}", group);
		
		/* Transaction Start */
		this.tranManager = getTransaction(true);
		try {
			this.tranManager.tranStart();
		
		if(group.getStoreInfoList().get(0).getStoreCode() != null) {
			 if(this.convertToBoolean(this.sqlSession.selectOne("isStoreCode", group))) {
				 
				 String message =	"StoreCode 오류: 이미 사용중인 상점코드입니다." ;
				 group.setMessage(message);
			 }
		
		}
	} catch (Exception e) {e.printStackTrace();} 
		finally {this.tranManager.tranEnd();}
		
	}
	
	
	private boolean convertToBoolean(int value) {
		return (value >= 1)? true : false;
	}
	
	
}
